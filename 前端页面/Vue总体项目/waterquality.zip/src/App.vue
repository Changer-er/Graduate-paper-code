<script setup>

import homepageVue from './homepage.vue';
</script>

<template>
  <homepageVue />
</template>

<style scoped></style>
