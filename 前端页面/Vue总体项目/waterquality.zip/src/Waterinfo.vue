<script setup>
import { ref, onMounted } from 'vue'
const temp_min = ref(0);
const temp_max = ref(0);
const DisO2_min = ref(0);
const DisO2_max = ref(0);
const PH_min = ref(0);
const PH_max = ref(0);
const Conduct_min = ref(0);
const Conduct_max = ref(0);
const BOD_min = ref(0);
const BOD_max = ref(0);
const Nitr_min = ref(0);
const Nitr_max = ref(0);
const FCI_min = ref(0);
const FCI_max = ref(0);
const TCI_min = ref(0);
const TCI_max = ref(0);
const item_length = ref(0)
</script>

